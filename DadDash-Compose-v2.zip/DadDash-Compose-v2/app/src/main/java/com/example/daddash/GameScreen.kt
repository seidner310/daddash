package com.example.daddash.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.daddash.R
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.random.Random

enum class Station { Toddler, Infant }
enum class ToddlerTask { Toy, Snack, Story }
enum class InfantTask { Bottle, Pacifier, Lullaby }

@Composable
fun GameScreen() {
    var hearts by remember { mutableStateOf(3) }
    var score by remember { mutableStateOf(0) }
    var playing by remember { mutableStateOf(true) }
    var dadPos by remember { mutableStateOf(0.5f) }
    var dadTarget by remember { mutableStateOf(0.5f) }
    var toddlerReq by remember { mutableStateOf<ToddlerTask?>(null) }
    var infantReq by remember { mutableStateOf<InfantTask?>(null) }
    var toddlerTimer by remember { mutableStateOf(0) }
    var infantTimer by remember { mutableStateOf(0) }
    val rand = remember { Random(System.currentTimeMillis()) }

    LaunchedEffect(playing) {
        val start = System.currentTimeMillis()
        while (playing) {
            delay(1000L)
            score += 5
            if (toddlerReq == null) { toddlerReq = ToddlerTask.entries[rand.nextInt(ToddlerTask.entries.size)]; toddlerTimer = 7 }
            if (infantReq == null) { infantReq = InfantTask.entries[rand.nextInt(InfantTask.entries.size)]; infantTimer = 6 }
            if (toddlerReq != null) { toddlerTimer -= 1; if (toddlerTimer <= 0) { hearts -= 1; toddlerReq = null } }
            if (infantReq != null) { infantTimer -= 1; if (infantTimer <= 0) { hearts -= 1; infantReq = null } }
            if (hearts <= 0) playing = false
        }
    }
    LaunchedEffect(dadTarget, playing) {
        while (playing && kotlin.math.abs(dadTarget - dadPos) > 0.001f) {
            dadPos += (dadTarget - dadPos) * 0.2f
            delay(16L)
        }
    }

    fun fulfillToddler(task: ToddlerTask) { if (dadPos < 0.25f && toddlerReq == task) { score += 100; toddlerReq = null } }
    fun fulfillInfant(task: InfantTask) { if (dadPos > 0.75f && infantReq == task) { score += 100; infantReq = null } }

    Box(
        modifier = Modifier.fillMaxSize().background(Color(0xFFF5F2EA))
            .pointerInput(Unit) { detectTapGestures { o -> dadTarget = if (o.x < size.width/2f) 0f else 1f; if (!playing) { hearts=3; score=0; toddlerReq=null; infantReq=null; playing=true } } }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            drawRect(Color(0xFFE7DCCF))
            drawLine(Color(0xFFCCBBAA), Offset(size.width/2, 0f), Offset(size.width/2, size.height), strokeWidth = 6f)
        }
        Column(Modifier.fillMaxHeight().width(0.dp).weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(24.dp))
            Image(painterResource(R.drawable.toddler_head), contentDescription = null, modifier = Modifier.size(140.dp))
            Spacer(Modifier.height(12.dp)); Text("Toddler", fontWeight = FontWeight.Bold); Spacer(Modifier.height(8.dp))
            Row { Text((toddlerReq?.name ?: "Chillin'")); if (toddlerTimer>0) Text("  ${toddlerTimer}s", color=Color(0xFFAA0000), fontWeight=FontWeight.Bold) }
        }
        Column(Modifier.fillMaxHeight().width(0.dp).weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(24.dp))
            Image(painterResource(R.drawable.baby_head), contentDescription = null, modifier = Modifier.size(140.dp))
            Spacer(Modifier.height(12.dp)); Text("Infant", fontWeight = FontWeight.Bold); Spacer(Modifier.height(8.dp))
            Row { Text((infantReq?.name ?: "Content")); if (infantTimer>0) Text("  ${infantTimer}s", color=Color(0xFFAA0000), fontWeight=FontWeight.Bold) }
        }
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomStart) {
            Row(Modifier.fillMaxWidth().padding(bottom = 120.dp)) {
                Spacer(Modifier.weight(dadPos))
                Image(painterResource(R.drawable.dad_head), contentDescription = null, modifier = Modifier.size(110.dp))
                Spacer(Modifier.weight(1f - dadPos))
            }
        }
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Bottom) {
            Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("❤️".repeat(hearts) + "  Score: $score", fontSize = 18.sp)
                if (!playing) Text("Game Over — Tap to restart", color = Color.Red, fontWeight = FontWeight.Bold)
            }
            if (dadPos < 0.5f) {
                Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                    Button(onClick = { fulfillToddler(ToddlerTask.Toy) }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6CB7FF))) { Text("Toy") }
                    Button(onClick = { fulfillToddler(ToddlerTask.Snack) }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6CB7FF))) { Text("Snack") }
                    Button(onClick = { fulfillToddler(ToddlerTask.Story) }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6CB7FF))) { Text("Story") }
                }
            } else {
                Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                    Button(onClick = { fulfillInfant(InfantTask.Bottle) }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6CB7FF))) { Text("Bottle") }
                    Button(onClick = { fulfillInfant(InfantTask.Pacifier) }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6CB7FF))) { Text("Pacifier") }
                    Button(onClick = { fulfillInfant(InfantTask.Lullaby) }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6CB7FF))) { Text("Lullaby") }
                }
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}