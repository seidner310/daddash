# DadDash (Android, Jetpack Compose)

A cozy time-management game: run between your toddler and infant to keep them happy.
Tap left/right to move Dad; tap the on-screen buttons to fulfill each child's request.

## Build (APK)
1. Install Android Studio and open this folder.
2. Build debug APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
   Output: `app/build/outputs/apk/debug/app-debug.apk`

## Replace Head Images
Add your cutout PNGs here and keep these names:
- `app/src/main/res/drawable/dad_head.png`
- `app/src/main/res/drawable/toddler_head.png`
- `app/src/main/res/drawable/baby_head.png`

(Placeholders are included so it runs out of the box.)

## GitHub Actions
Use the YAML I shared earlier (or ask me to add it for you) to build an APK entirely from your phone.