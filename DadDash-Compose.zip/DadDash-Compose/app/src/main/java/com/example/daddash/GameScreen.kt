package com.example.daddash.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.daddash.R
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.random.Random

enum class Station { Toddler, Infant }
enum class ToddlerTask { Toy, Snack, Story }
enum class InfantTask { Bottle, Pacifier, Lullaby }

@Composable
fun GameScreen() {
    var hearts by remember { mutableStateOf(3) }
    var score by remember { mutableStateOf(0) }
    var elapsed by remember { mutableStateOf(0L) }
    var playing by remember { mutableStateOf(true) }

    // Dad position: 0f = left (toddler), 1f = right (infant)
    var dadPos by remember { mutableStateOf(0.5f) }
    var dadTarget by remember { mutableStateOf(0.5f) }

    var toddlerReq by remember { mutableStateOf<ToddlerTask?>(null) }
    var infantReq by remember { mutableStateOf<InfantTask?>(null) }
    var toddlerTimer by remember { mutableStateOf(0) }
    var infantTimer by remember { mutableStateOf(0) }

    val rand = remember { Random(System.currentTimeMillis()) }

    // Spawning and timers
    LaunchedEffect(playing) {
        val start = System.currentTimeMillis()
        while (playing) {
            delay(1000L)
            elapsed = System.currentTimeMillis() - start
            score += 5 // time bonus

            // Spawn tasks if empty
            if (toddlerReq == null) {
                toddlerReq = ToddlerTask.entries[rand.nextInt(ToddlerTask.entries.size)]
                toddlerTimer = 7
            }
            if (infantReq == null) {
                infantReq = InfantTask.entries[rand.nextInt(InfantTask.entries.size)]
                infantTimer = 6
            }

            // Tick timers
            if (toddlerReq != null) {
                toddlerTimer -= 1
                if (toddlerTimer <= 0) { hearts -= 1; toddlerReq = null }
            }
            if (infantReq != null) {
                infantTimer -= 1
                if (infantTimer <= 0) { hearts -= 1; infantReq = null }
            }

            if (hearts <= 0) playing = false
        }
    }

    // Smooth dad movement toward target
    LaunchedEffect(dadTarget, playing) {
        while (playing && abs(dadTarget - dadPos) > 0.001f) {
            dadPos += (dadTarget - dadPos) * 0.2f
            delay(16L)
        }
    }

    fun fulfillToddler(task: ToddlerTask) {
        if (!playing) return
        // must be near left side
        if (dadPos < 0.25f && toddlerReq == task) {
            score += 100
            toddlerReq = null
        } else {
            score = maxOf(0, score - 10)
        }
    }

    fun fulfillInfant(task: InfantTask) {
        if (!playing) return
        if (dadPos > 0.75f && infantReq == task) {
            score += 100
            infantReq = null
        } else {
            score = maxOf(0, score - 10)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F2EA))
            .pointerInput(Unit) {
                detectTapGestures { offset ->
                    dadTarget = if (offset.x < size.width/2f) 0f else 1f
                    if (!playing) {
                        // Restart
                        hearts = 3; score = 0; elapsed = 0
                        toddlerReq = null; infantReq = null
                        toddlerTimer = 0; infantTimer = 0
                        playing = true
                    }
                }
            }
    ) {
        // Background: two stations
        Canvas(Modifier.fillMaxSize()) {
            // floor
            drawRect(Color(0xFFE7DCCF))
            // center divider
            drawLine(Color(0xFFCCBBAA), Offset(size.width/2, 0f), Offset(size.width/2, size.height), strokeWidth = 6f)
        }

        // Toddler station (left)
        Column(
            Modifier
                .fillMaxHeight()
                .width(0.dp)
                .weight(1f),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top
        ) {
            Spacer(Modifier.height(24.dp))
            Image(painterResource(R.drawable.toddler_head), contentDescription = "Toddler", modifier = Modifier.size(140.dp))
            Spacer(Modifier.height(12.dp))
            Text("Toddler", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            RequestBubbleToddler(toddlerReq, toddlerTimer)
        }

        // Infant station (right)
        Column(
            Modifier
                .fillMaxHeight()
                .width(0.dp)
                .weight(1f),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top
        ) {
            Spacer(Modifier.height(24.dp))
            Image(painterResource(R.drawable.baby_head), contentDescription = "Infant", modifier = Modifier.size(140.dp))
            Spacer(Modifier.height(12.dp))
            Text("Infant", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            RequestBubbleInfant(infantReq, infantTimer)
        }

        // Dad (bottom, center between stations based on dadPos)
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomStart) {
            val pad = 24.dp
            Row(Modifier.fillMaxWidth().padding(bottom = 120.dp)) {
                Spacer(Modifier.weight(dadPos))
                Image(painterResource(R.drawable.dad_head), contentDescription = "Dad", modifier = Modifier.size(110.dp))
                Spacer(Modifier.weight(1f - dadPos))
            }
        }

        // Controls row
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Bottom) {
            // HUD
            Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("❤️"*hearts + "  Score: $score", fontSize = 18.sp)
                if (!playing) Text("Game Over — Tap to restart", color = Color.Red, fontWeight = FontWeight.Bold)
            }

            // Buttons: context based on side
            if (dadPos < 0.5f) {
                Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                    SmallBtn("Toy") { fulfillToddler(ToddlerTask.Toy) }
                    SmallBtn("Snack") { fulfillToddler(ToddlerTask.Snack) }
                    SmallBtn("Story") { fulfillToddler(ToddlerTask.Story) }
                }
            } else {
                Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                    SmallBtn("Bottle") { fulfillInfant(InfantTask.Bottle) }
                    SmallBtn("Pacifier") { fulfillInfant(InfantTask.Pacifier) }
                    SmallBtn("Lullaby") { fulfillInfant(InfantTask.Lullaby) }
                }
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun SmallBtn(label: String, onClick: () -> Unit) {
    Button(onClick = onClick, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6CB7FF))) {
        Text(label)
    }
}

@Composable
private fun RequestBubbleToddler(req: ToddlerTask?, timer: Int) {
    val text = when (req) {
        ToddlerTask.Toy -> "Wants a Toy"
        ToddlerTask.Snack -> "Wants a Snack"
        ToddlerTask.Story -> "Wants a Story"
        null -> "Chillin’"
    }
    Bubble(text, timer)
}

@Composable
private fun RequestBubbleInfant(req: InfantTask?, timer: Int) {
    val text = when (req) {
        InfantTask.Bottle -> "Needs Bottle"
        InfantTask.Pacifier -> "Needs Pacifier"
        InfantTask.Lullaby -> "Needs Lullaby"
        null -> "Content"
    }
    Bubble(text, timer)
}

@Composable
private fun Bubble(text: String, timer: Int) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(text, modifier = Modifier.background(Color(0xFFFFF1A8)).padding(8.dp))
        if (timer > 0) Text("  $timer s", color = Color(0xFFAA0000), fontWeight = FontWeight.Bold)
    }
}